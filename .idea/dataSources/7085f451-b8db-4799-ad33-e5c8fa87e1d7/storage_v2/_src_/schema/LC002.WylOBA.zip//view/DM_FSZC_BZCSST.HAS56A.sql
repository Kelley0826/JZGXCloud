create view DM_FSZC_BZCSST as
SELECT fsroconffa.fsroconffa_nm,
    fsroconffa.fsroconffa_bh,
    fsroconffa.fsroconffa_mc,
    max(fsroconffa.fsroconffa_zt) AS fsroconffa_zt,
    max(fsroconffa.fsroconffa_cjr) AS fsroconffa_cjr,
    max(fsroconffa.fsroconffa_cjsj) AS fsroconffa_cjsj,
    max(fsroconffa.fsroconffa_xgr) AS fsroconffa_xgr,
    max(fsroconffa.fsroconffa_xgsj) AS fsroconffa_xgsj,
    max(fsroconffa.fsroconffa_note) AS fsroconffa_note,
    max(fsroconffa.fsroconffa_cjdw) AS fsroconffa_cjdw,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROBX_CHECKJEONSAVE' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrobx_checkjeonsave,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROBX_ZFMXZHFW' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrobx_zfmxzhfw,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROBX_ZFMXYHZHLRFS' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrobx_zfmxyhzhlrfs,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROBX_ZFMXKHHLRFS' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrobx_zfmxkhhlrfs,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROBX_ZFMXYHZHXSFS' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrobx_zfmxyhzhxsfs,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROBX_ZFMXYGZHIFJS' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrobx_zfmxygzhifjs,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROBX_ZFMXWLZHIFJS' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrobx_zfmxwlzhifjs,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROBX_JKHXNOXJ' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrobx_jkhxnoxj,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROBX_JKHXXJHKJS' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrobx_jkhxxjhkjs,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROBX_ZFIFFH' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrobx_zfiffh,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROBX_ZFIFZFPZ' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrobx_zfifzfpz,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROJK_ZFMXZHFW' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrojk_zfmxzhfw,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROJK_ZFMXYHZHLRFS' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrojk_zfmxyhzhlrfs,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROJK_ZFMXKHHLRFS' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrojk_zfmxkhhlrfs,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROJK_ZFMXYHZHXSFS' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrojk_zfmxyhzhxsfs,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROJK_ZFMXYGZHIFJS' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrojk_zfmxygzhifjs,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROJK_ZFMXWLZHIFJS' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrojk_zfmxwlzhifjs,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROJK_ZFIFFH' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrojk_zfiffh,
    max((
        CASE fsroconf.fsroconf_key
            WHEN 'FSROJK_ZFIFZFPZ' THEN fsroconf.fsroconf_value
            ELSE ''
        END)) AS fsrojk_zfifzfpz
   FROM (fsroconffa
     LEFT JOIN fsroconf ON (fsroconffa.fsroconffa_nm = fsroconf.fsroconf_fanm))
  GROUP BY fsroconffa.fsroconffa_bh, fsroconffa.fsroconffa_mc, fsroconffa.fsroconffa_nm
/

