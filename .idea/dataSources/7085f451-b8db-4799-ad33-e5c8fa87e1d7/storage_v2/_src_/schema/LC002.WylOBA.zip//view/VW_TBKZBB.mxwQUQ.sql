create view VW_TBKZBB as
select tbkzmx_kznm,tbkzmx_bbnm,tbkzmx_condi,tbbbdy_dymc,tbkzmx_mxnm,tbsjmx_mxmc,tbkzmx_yjlx,tbkzmx_guid,QJKZN,QJKZJ,QJKZY,QJKZX,QJKZZ,LJKZN,LJKZJ,LJKZY,LJKZX,LJKZZ,
YJKZN,YJKZJ,YJKZY,YJKZX,YJKZZ
 from tbkzmx join
(select tbqjkz_lbnm,tbqjkz_mxnm,tbqjkz_bbnm,
MAX(case WHEN TBQJKZ_QJZQ='01' and tbqjkz_kzlx='QJ' then 'True' else 'False' END) AS QJKZN,
MAX(case WHEN TBQJKZ_QJZQ='02' and tbqjkz_kzlx='QJ' then 'True' else 'False' END) AS QJKZJ,
MAX(case WHEN TBQJKZ_QJZQ='03' and tbqjkz_kzlx='QJ' then 'True' else 'False' END) AS QJKZY,
MAX(case WHEN TBQJKZ_QJZQ='10' and tbqjkz_kzlx='QJ' then 'True' else 'False' END) AS QJKZX,
MAX(case WHEN TBQJKZ_QJZQ='11' and tbqjkz_kzlx='QJ' then 'True' else 'False' END) AS QJKZZ,
MAX(case WHEN TBQJKZ_QJZQ='01' and tbqjkz_kzlx='LJ' then 'True' else 'False' END) AS LJKZN,
MAX(case WHEN TBQJKZ_QJZQ='02' and tbqjkz_kzlx='LJ' then 'True' else 'False' END) AS LJKZJ,
MAX(case WHEN TBQJKZ_QJZQ='03' and tbqjkz_kzlx='LJ' then 'True' else 'False' END) AS LJKZY,
MAX(case WHEN TBQJKZ_QJZQ='10' and tbqjkz_kzlx='LJ' then 'True' else 'False' END) AS LJKZX,
MAX(case WHEN TBQJKZ_QJZQ='11' and tbqjkz_kzlx='LJ' then 'True' else 'False' END) AS LJKZZ,
MAX(case WHEN TBQJKZ_QJZQ='01' and tbqjkz_kzlx='YJ' then 'True' else 'False' END) AS YJKZN,
MAX(case WHEN TBQJKZ_QJZQ='02' and tbqjkz_kzlx='YJ' then 'True' else 'False' END) AS YJKZJ,
MAX(case WHEN TBQJKZ_QJZQ='03' and tbqjkz_kzlx='YJ' then 'True' else 'False' END) AS YJKZY,
MAX(case WHEN TBQJKZ_QJZQ='10' and tbqjkz_kzlx='YJ' then 'True' else 'False' END) AS YJKZX,
MAX(case WHEN TBQJKZ_QJZQ='11' and tbqjkz_kzlx='YJ' then 'True' else 'False' END) AS YJKZZ
from tbqjkz
group by TBQJKZ_LBNM,tbqjkz_mxnm,tbqjkz_bbnm) T 
on tbkzmx_kznm=t.tbqjkz_lbnm and tbkzmx_bbnm=t.tbqjkz_bbnm 
join TBSJMX on TBSJMX_MXNM = tbkzmx_mxnm
join tbbbdy on tbbbdy_dynm=tbkzmx_bbnm
/

