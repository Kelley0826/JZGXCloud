create view VW_BFMASTERORGANIZATION as
SELECT b.id,
    b.code,
    b.name_chs,
    b.name_cht,
    b.name_en,
    b.name_es,
    b.name_pt,
    b.organizationcode,
    b.taxcreditrating,
    taxregion.fullname_chs as taxregion_chs,
    taxregion.fullname_cht as taxregion_cht,
    taxregion.fullname_en as taxregion_en,
    taxregion.fullname_es as taxregion_es,
    taxregion.fullname_pt as taxregion_pt,
    b.legalrepresentative,
    b.tel,
    b.namefortax,
    registrationtype.name_chs as registrationtype_chs,
    registrationtype.name_cht as registrationtype_cht,
    registrationtype.name_en as registrationtype_en,
    registrationtype.name_es as registrationtype_es,
    registrationtype.name_pt as registrationtype_pt,
    b.treeinfo_isdetail,
    b.treeinfo_layer,
    b.treeinfo_path,
    b.state_disabletime,
    b.state_asyncdeletestatus,
    b.state_isenabled,
    b.taxorg
   FROM bfmasterorganization b
   left join bfadmindivision taxregion on b.taxregion  = taxregion.id 
   left join bfcodeitems registrationtype on b.registrationtype  = registrationtype.id
/

