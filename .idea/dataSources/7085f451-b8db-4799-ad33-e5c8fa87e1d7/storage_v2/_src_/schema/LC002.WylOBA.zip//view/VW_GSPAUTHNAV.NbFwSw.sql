create view VW_GSPAUTHNAV as
SELECT Id,Code,Name_chs AS Name_chs,Name_en AS Name_en,name_cht as name_cht,name_es as name_es, name_pt as name_pt,IsDetail,Layer,ParentId,SortOrder,'1' AS HierarchicalType,'' AS Path,'' AS State FROM gspbusinessobject WHERE layer > 1
/

