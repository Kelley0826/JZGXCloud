create view VWBFACCORGANDLEDGER as
select ID, Code, Name_chs, Name_cht,Name_en,Name_es,Name_pt,
enableFlag, isDisable, disableYear,
treeInfo_path, treeInfo_Layer, '0' as treeInfo_isDetail,
parentID, sortOrder, '核算组织' as orgType,'0' as isGovAcc,null as Version,
null as orgName_chs,null as orgName_cht, null as orgName_en,null as orgName_es,null as orgName_pt
from bfAccountingOrganization
union all
select b.ID, b.code, b.Name_chs, b.Name_cht,b.Name_en,b.Name_es,b.Name_pt,
b.enableFlag, b.isDisable, b.disableYear,
c.treeInfo_path ||  substr('...' || cast(row_number() over (PARTITION BY b.AccOrgID order by b.code) as varchar(4)), -4), 
c.treeInfo_Layer + 1, '1',
b.AccOrgID, row_number() over (PARTITION BY b.AccOrgID order by b.code), '核算账簿',b.IsGovAcc,null,
c.name_chs as OrgName_chs,c.name_cht as OrgName_cht,c.name_en as OrgName_en,c.name_es as OrgName_es,c.name_pt as OrgName_pt
from bfLedger b
inner join bfAccountingOrganization c on (b.AccorgID = c.id)
/

