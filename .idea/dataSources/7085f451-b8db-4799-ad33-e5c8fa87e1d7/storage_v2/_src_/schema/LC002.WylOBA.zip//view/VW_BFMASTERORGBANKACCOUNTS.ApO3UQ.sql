create view VW_BFMASTERORGBANKACCOUNTS as
select
	masterbank.id,
	masterbank.accountcode,
	masterbank.accountname,
	masterbank.accounttype,
	masterbank.city,
	masterbank.inbank as inbankid,
	bank.name_chs as bankname_chs,
	bank.name_cht as bankname_cht,
	bank.name_en as bankname_en,
	bank.name_es as bankname_es,
	bank.name_pt as bankname_pt,
	bank.name_chs || ' ' ||  masterbank.accountcode as bankaccount_chs, 
	bank.name_cht || ' ' ||  masterbank.accountcode as bankaccount_cht, 
	bank.name_en || ' ' ||  masterbank.accountcode as bankaccount_en, 
	bank.name_es || ' ' ||  masterbank.accountcode as bankaccount_es, 
	bank.name_pt || ' ' ||  masterbank.accountcode as bankaccount_pt, 
	masterbank.ismain,
	masterbank.masterorgid,
	masterbank.province,
	masterbank.remark,
	masterbank.state_asyncdeletestatus,
	masterbank.state_disabletime,
	masterbank.state_isenabled,
	masterbank.timestamp_createdby,
	masterbank.timestamp_createdon,
	masterbank.timestamp_lastchangedby,
	masterbank.timestamp_lastchangedon
from
	bfmasterorgbankaccounts masterbank
join bfmasterorganization bfmaster on
	masterbank.masterorgid = bfmaster.id 
	and bfmaster.state_isenabled = '1'
join bfbank bank on
	bank.id = masterbank.inbank
/

