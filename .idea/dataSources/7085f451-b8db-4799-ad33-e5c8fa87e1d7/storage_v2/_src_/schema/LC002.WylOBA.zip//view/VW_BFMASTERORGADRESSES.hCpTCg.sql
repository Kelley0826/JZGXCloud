create view VW_BFMASTERORGADRESSES as
select
	adress.id,
	adress.addrtype as addrtypeid,
	addrtype.name_chs as addrtypename_chs,
	addrtype.name_cht as addrtypename_cht,
	addrtype.name_en as addrtypename_en,
	addrtype.name_es as addrtypename_es,
	addrtype.name_pt as addrtypename_pt,
	adress.adminarea as adminareaid,
	admindiv.name_chs as adminareaname_chs,
	admindiv.name_cht as adminareaname_cht,
	admindiv.name_en as adminareaname_en,	
	admindiv.name_es as adminareaname_es,
	admindiv.name_pt as adminareaname_pt,
	admindiv.fullname_chs as adminareafullname_chs,
	admindiv.fullname_cht as adminareafullname_cht,	
	admindiv.fullname_en as adminareafullname_en,
	admindiv.fullname_es as adminareafullname_es,
	admindiv.fullname_pt as adminareafullname_pt,
	bfmaster.tel as tel,
	(admindiv.fullname_chs || ' ') || bfmaster.tel AS addresstel_chs,	
	(admindiv.fullname_cht || ' ') || bfmaster.tel AS addresstel_cht,	
	(admindiv.fullname_en || ' ') || bfmaster.tel AS addresstel_en,
	(admindiv.fullname_es || ' ') || bfmaster.tel AS addresstel_es,	
	(admindiv.fullname_pt || ' ') || bfmaster.tel AS addresstel_pt,	
	adress.countryorregion as countryorregionid,
	countryorregion.name_chs as countryorregionname_chs,
	countryorregion.name_cht as countryorregionname_cht,
	countryorregion.name_en as countryorregionname_en,
	countryorregion.name_es as countryorregionname_es,
	countryorregion.name_pt as countryorregionname_pt,
	adress.ismain,
	adress.masterorgid,
	adress.remark,
	adress.state_asyncdeletestatus,
	adress.state_disabletime,
	adress.state_isenabled,
	adress.streetno,
	adress.timestamp_createdby,
	adress.timestamp_createdon,
	adress.timestamp_lastchangedby,
	adress.timestamp_lastchangedon
from
	bfmasterorgadresses adress
join bfmasterorganization bfmaster on
	adress.masterorgid = bfmaster.id 
	and adress.state_isenabled ='1' 
	and bfmaster.state_isenabled ='1'
join bfadmindivision admindiv on
	adress.adminarea = admindiv.id
join bfcodeitems addrtype on
	addrtype.id = 'fadaa0dd-e6c2-4e31-b7a2-8a40e84016bc'
	and adress.addrtype = addrtype.id
join bfnationalandregionaldict countryorregion on
	countryorregion.id = adress.countryorregion
/

