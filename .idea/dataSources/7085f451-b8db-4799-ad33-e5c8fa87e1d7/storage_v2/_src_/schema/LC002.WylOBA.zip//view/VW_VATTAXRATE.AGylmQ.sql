create view VW_VATTAXRATE as
SELECT bftaxcode.applicabletaxrate AS taxrate,
    (round((bftaxcode.applicabletaxrate * (100)), 2) || '%') AS disrate
   FROM bftaxcode
  WHERE (((bftaxcode.taxsystemid) = '1ace1d4c-2285-2566-b126-22452eeb381d') AND ((bftaxcode.taxtypeid) = '62f62cde-1396-68be-ac2b-083a01b170bf'))
/

