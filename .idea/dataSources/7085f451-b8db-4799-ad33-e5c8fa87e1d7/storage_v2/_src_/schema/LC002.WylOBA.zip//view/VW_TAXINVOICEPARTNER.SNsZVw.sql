create view VW_TAXINVOICEPARTNER as
SELECT bfpartner.id,
    bfpartner.code,
    bfpartner.taxpayer AS taxpayername,
    bfpartner.organizationcode AS taxpayerid,
    bfpartner.iscustomer,
    bfpartner.isvender,
    bfpartner.typeoftaxpayer AS taxpayertype,
    addres.fullname_chs AS address,
    pa.contactnum AS telphone,
    addres.fullname_chs || pa.streetno || ' '|| pa.contactnum AS addressandtelphone,
    pb.accountname_chs AS bank,
    pb.accountcode AS bankaccount,
    pb.accountname_chs || ' ' || pb.accountcode AS bankandaccount,
    bfpartner.taxpayeremail AS email,
    bfpartner.telforinvoice AS phonenum,
    bfpartner.state_isenabled
   FROM bfpartner
     LEFT JOIN BFPARTNERBANKACCOUNTS pb ON pb.partnerid=bfpartner.id AND pb.ismain = '1'
     LEFT JOIN BFPARTNERADDRESS pa ON pa.partnerid=bfpartner.id AND pa.ismain = '1'
     LEFT JOIN bfcodeitems addrtype ON addrtype.id = 'c6672a89-a4e9-4d41-846d-87c017ba119d' AND pa.addrtype = addrtype.id
     LEFT JOIN bfadmindivision addres ON pa.adminarea = addres.id
/

