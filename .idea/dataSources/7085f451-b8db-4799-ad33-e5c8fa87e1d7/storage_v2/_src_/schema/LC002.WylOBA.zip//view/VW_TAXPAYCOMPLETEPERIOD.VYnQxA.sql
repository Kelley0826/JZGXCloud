create view VW_TAXPAYCOMPLETEPERIOD as
SELECT vwperiod.id AS id, vwperiod.type AS type, vwperiod.name AS name, vwperiod.year AS year, vwperiod.taxperiod AS period, vwperiod.periodstarttime AS periodstarttime, vwperiod.periodendtime AS periodendtime, concat (vwperiod.year, vwperiod.taxperiod) as taxperiod FROM taxorgpaytaxcompleteperiod vwperiod
/

