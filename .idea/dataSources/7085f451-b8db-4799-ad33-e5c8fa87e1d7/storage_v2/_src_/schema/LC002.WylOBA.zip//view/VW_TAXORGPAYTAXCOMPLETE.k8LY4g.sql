create view VW_TAXORGPAYTAXCOMPLETE as
SELECT a.id,  a.taxorgid,  b.type,  b.year,  b.taxperiod,  b.name,  b.periodstarttime,  b.periodendtime,  a.state,  a.completetime,  gspuser.name_chs as paytaxby,  a.createdby,  a.createdon,  a.lastchangedby,  a.lastchangedon FROM taxorgpaytaxcompleteobject a LEFT JOIN taxorgpaytaxcompleteperiod b ON a.taxperiodid = b.id LEFT JOIN gspuser gspuser ON gspuser.id = a.paytaxby
/

