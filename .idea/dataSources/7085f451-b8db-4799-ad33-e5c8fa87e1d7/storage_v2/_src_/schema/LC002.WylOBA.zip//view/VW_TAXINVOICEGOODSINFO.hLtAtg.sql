create view VW_TAXINVOICEGOODSINFO as
SELECT bfmaterials.id,
    bfmaterials.code,
	bfmaterials.name_chs AS name,
    bfmaterials.name_chs AS name_chs,
    bfmaterials.name_cht AS name_cht,
    bfmaterials.name_en AS name_en,
    bfmaterials.name_es AS name_es,
    bfmaterials.name_pt AS name_pt,
    CONCAT(CONCAT( CONCAT('*' , goodscoding.goodsabbreviation),'*') , bfmaterials.name_chs)  AS goodsname_chs,
    CONCAT(CONCAT( CONCAT('*' , goodscoding.goodsabbreviation),'*') ,  bfmaterials.name_cht)  AS goodsname_cht,
    CONCAT(CONCAT( CONCAT('*' , goodscoding.goodsabbreviation),'*') ,  bfmaterials.name_en)  AS goodsname_en,
    CONCAT(CONCAT( CONCAT('*' , goodscoding.goodsabbreviation),'*') ,  bfmaterials.name_es)  AS goodsname_es,
    CONCAT(CONCAT( CONCAT('*' , goodscoding.goodsabbreviation),'*') ,  bfmaterials.name_pt)  AS goodsname_pt,
    bfmaterials.rate AS deftaxrate,
    bfmaterials.taxbillspecification AS specifications,
    munit.name_chs AS unit,
    munit.name_chs AS unit_chs,
	munit.name_cht AS unit_cht,
	munit.name_en AS unit_en,
	munit.name_es AS unit_es,
	munit.name_pt AS unit_pt,
    goodscoding.code AS goodscoding,
    goodscoding.goodsabbreviation,
    bfmaterials.defaultunitprice AS defaultprice,
    bfmaterials.unitpricetaxincluded AS priceplustax,
    bfmaterials.enjoypreferentialpolicies AS isfavorable,
    bfmaterials.contentofpreferentialpolicies AS favorablecontent
   FROM ((bfmaterials
     LEFT JOIN bfmeasureunit munit ON (((munit.id) = (bfmaterials.taxbillmeasureunit))))
     LEFT JOIN bftaxgoodscoding goodscoding ON (((goodscoding.id) = (bfmaterials.taxclassification))))
   WHERE bfmaterials.STATE_ISENABLED = '1'
/

