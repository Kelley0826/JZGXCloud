create view BABAPDATASETCATEGORY as
SELECT s1.id as Id,category_id  AS Pid,s1.user_id AS UserId,dataset_code AS Code,dataset_name_chs AS Name_CHS,dataset_name_cht AS Name_CHT,dataset_name_en AS Name_EN,dataset_name_es AS Name_ES,dataset_name_pt AS Name_PT,dataset_type AS Type,'dataset' AS ResType, create_time AS CreateTime,update_time  AS UpdateTime FROM BABAPdataset s1 where backend_type = 2 union all SELECT s2.id as Id,category_pid  AS Pid,s2.user_id AS UserId, 
category_code  AS Code,category_name_chs AS Name_CHS,category_name_cht AS Name_CHT,category_name_en AS Name_EN,category_name_es AS Name_ES,category_name_pt AS Name_PT,category_type AS Type,'category' AS ResType, create_time AS CreateTime,update_time AS UpdateTime FROM BABAPCategory s2 where category_type ='dataset' and backend_type = 2
/

