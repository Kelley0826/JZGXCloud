create view VW_BFDFTAXORG as
SELECT bfdftaxorg.id,
    bfdftaxorg.bfmsorg,
    bfmasterorganization.code,
    bfmasterorganization.name_chs AS name,
    bfmasterorganization.name_chs AS name_chs,
    bfmasterorganization.name_cht AS name_cht,
    bfmasterorganization.name_en AS name_en,
    bfmasterorganization.name_es AS name_es,
    bfmasterorganization.name_pt AS name_pt,
    bfmasterorganization.organizationcode AS taxid,
    (address.fullname_chs  || ' ' ) || bfmasterorganization.tel  AS addressandtel,
    (address.fullname_chs  || ' ' ) || bfmasterorganization.tel  AS addressandtel_chs,
    (address.fullname_cht  || ' ' ) || bfmasterorganization.tel  AS addressandtel_cht,
    (address.fullname_en  || ' ' ) || bfmasterorganization.tel  AS addressandtel_en,
    (address.fullname_es  || ' ' ) || bfmasterorganization.tel  AS addressandtel_es,
    (address.fullname_pt  || ' ' ) || bfmasterorganization.tel  AS addressandtel_pt,
    (bfbank.name_chs  || ' ' ) || bfmasterorgbankaccounts.accountcode  AS bankandaccount,
    (bfbank.name_chs  || ' ' ) || bfmasterorgbankaccounts.accountcode  AS bankandaccount_chs,
    (bfbank.name_cht  || ' ' ) || bfmasterorgbankaccounts.accountcode  AS bankandaccount_cht,
    (bfbank.name_en  || ' ' ) || bfmasterorgbankaccounts.accountcode  AS bankandaccount_en,
    (bfbank.name_es  || ' ' ) || bfmasterorgbankaccounts.accountcode  AS bankandaccount_es,
    (bfbank.name_pt  || ' ' ) || bfmasterorgbankaccounts.accountcode  AS bankandaccount_pt,
    taxregion.fullname_chs as taxregion,
    taxregion.fullname_chs as taxregion_chs,
    taxregion.fullname_cht as taxregion_cht,
    taxregion.fullname_en as taxregion_en,
    taxregion.fullname_es as taxregion_es,
    taxregion.fullname_pt as taxregion_pt,
	taxregion.id as taxregionid,
    bfmasterorganization.tel,
    bfmasterorganization.taxcreditrating,
    industry.name_chs as industry,
    industry.name_chs as industry_chs,
    industry.name_cht as industry_cht,
    industry.name_en as industry_en,
    industry.name_es as industry_es,
    industry.name_pt as industry_pt,
    industry.id as industryid,
    registrationtype.name_chs as registrationtype,
    registrationtype.name_chs as registrationtype_chs,
    registrationtype.name_cht as registrationtype_cht,
    registrationtype.name_en as registrationtype_en,
    registrationtype.name_es as registrationtype_es,
    registrationtype.name_pt as registrationtype_pt,
    registrationtype.id as registrationtypeid,
    bfmasterorganization.legalrepresentative,
    bfmasterorganization.namefortax,
    bfdftaxorg.hightechen,
    bfdftaxorg.microen,
    bfdftaxorg.techmse,
    bfdftaxorg.treeinfo_isdetail AS isdetail,
    bfdftaxorg.treeinfo_layer AS layer,
    bfdftaxorg.treeinfo_path AS path,
    bfdftaxorg.updateinfo_createdby,
    bfdftaxorg.updateinfo_createdon,
    bfdftaxorg.updateinfo_lastchangedby,
    bfdftaxorg.updateinfo_lastchangedon,
    bfmasterorganization.state_asyncdeletestatus,
    bfmasterorganization.state_disabletime,
    bfmasterorganization.state_isenabled,
    bfmasterorganization.taxorg
   FROM bfdftaxorg
     JOIN bfmasterorganization ON bfdftaxorg.bfmsorg  = bfmasterorganization.id 
     left join bfmasterorgbankaccounts on bfmasterorgbankaccounts.masterorgid  = bfmasterorganization.id  and bfmasterorgbankaccounts.ismain ='1'
     left join bfbank on bfbank.id  = bfmasterorgbankaccounts.inbank 
     left join bfmasterorgadresses on bfmasterorgadresses.ismain ='1' and bfmasterorgadresses.addrtype ='fadaa0dd-e6c2-4e31-b7a2-8a40e84016bc' and bfmasterorgadresses.masterorgid =bfmasterorganization.id 
     left join bfcodeitems addrtype on addrtype.id ='fadaa0dd-e6c2-4e31-b7a2-8a40e84016bc' and bfmasterorgadresses.addrtype =addrtype.id 
     left join bfadmindivision address on bfmasterorgadresses.adminarea  = address.id 
     left join bfadmindivision taxregion on bfmasterorganization.taxregion  = taxregion.id 
     left join bfcodeitems industry on bfmasterorganization.industry  = industry.id 
     left join bfcodeitems registrationtype on bfmasterorganization.registrationtype  = registrationtype.id
/

