create view VW_TAXOUTCANCELVATINV as
SELECT inv.id,
    inv.taxorg,
    inv.invoicetype,
    inv.billingtype,
    inv.specialtaxkindsign,
    inv.invoicecode,
    inv.invoicenumber,
    inv.invoicedate,
    inv.buyertaxpayername,
    inv.buyertaxpayeridno,
    inv.amount,
    inv.taxamount,
    inv.amountplustax,
    inv.note,
    inv.sourcetype,
    inv.invalidsign
   FROM taxoutvatinvoice inv
  WHERE inv.invoicestate = '1'
/

