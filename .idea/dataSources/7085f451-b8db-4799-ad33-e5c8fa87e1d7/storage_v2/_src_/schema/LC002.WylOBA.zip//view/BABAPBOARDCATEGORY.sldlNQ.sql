create view BABAPBOARDCATEGORY as
SELECT s1.id as Id,category_id  AS Pid,s1.user_id AS UserId,boardcode AS Code,board_name_chs AS Name_CHS,board_name_cht AS Name_CHT,board_name_en AS Name_EN,board_name_es AS Name_ES,board_name_pt AS Name_PT,filetype AS Type,'board' AS ResType, create_time AS CreateTime,update_time  AS UpdateTime FROM BABAPboard s1 where backend_type = 2 union all SELECT s2.id as Id,category_pid  AS Pid,s2.user_id AS UserId, 
category_code  AS Code,category_name_chs AS Name_CHS,category_name_cht AS Name_CHT,category_name_en AS Name_EN,category_name_es AS Name_ES,category_name_pt AS Name_PT,category_type AS Type,'category' AS ResType, create_time AS CreateTime,update_time AS UpdateTime FROM BABAPCategory s2 where category_type ='board' and backend_type = 2
/

