create view ERMORGVIEW as
select
   Code LSBZDW_DWBH,
   name_chs LSBZDW_DWMC,
   orgtype LSBZDW_GSXZ,
   '' LSBZDW_GSLB,
   state_isenabled LSBZDW_QYBZ,
   treeinfo_path LSBZDW_DWNM,
   pnthrinfo_parentelement LSBZDW_SJGS,
   (case when (select count(1) from bfadminorganization where orgtype='9edf25d1-b991-4dde-90b9-30145422d24d' and pnthrinfo_parentelement=org.id)>0 then '0' else '1' end) LSBZDW_MX,
   '' LSBZDW_SH,
   (case when state_isenabled='1' then '0' else '1' end) LSBZDW_TYBZ,
   orgtype LSBZDW_DWLX,
   '' LSBZDW_SSHY,
   '' LSBZDW_ZGBM,
   '' LSBZDW_TYND,
   '' LSBZDW_DWQC,
   id LSBZDW_GUID,
   id LSBZDW_ID,
   treeinfo_layer LSBZDW_JS,
   '' LSBZDW_HY,
   sortorder LSBZDW_SORTORDER,
   timestamp_createdon CreatedTime,
   timestamp_lastchangedon LastModifiedTime,
   timestamp_createdby Creator,
   timestamp_lastchangedby LastModifier
from
   (select * from bfadminorganization where orgtype='9edf25d1-b991-4dde-90b9-30145422d24d')org
/

