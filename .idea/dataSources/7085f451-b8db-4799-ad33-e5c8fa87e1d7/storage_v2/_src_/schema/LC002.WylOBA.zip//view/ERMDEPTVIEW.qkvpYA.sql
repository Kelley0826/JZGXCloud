create view ERMDEPTVIEW as
select
   dep.id LSBMZD_ID,
   org.code LSBMZD_DWBH,
   dep.code LSBMZD_BMBH,
   '' LSBMZD_ZJM,
   dep.name_chs LSBMZD_BMMC,
   dep.treeinfo_layer LSBMZD_JS,
   dep.treeinfo_isdetail LSBMZD_MX,
   '' LSBMZD_LX,
   '' LSBMZD_DYDW,
   '' LSBMZD_DYBM,
   '' LSBMZD_SX,
   '' LSBMZD_HSF,
   (case when dep.state_isenabled='1' then '0' else '1' end) LSBMZD_TYBZ,
   '' LSBMZD_TYND,
   dep.treeinfo_path LSBMZD_FJM,
   dep.timestamp_createdby CreateUser,
   dep.timestamp_createdon CreateTime,
   dep.timestamp_lastchangedby LastModifiedUser, 
   dep.timestamp_lastchangedon LastModifiedTime,
   '' LSBMZD_BMFZR,
   '' LSBMZD_HSST,
   '' LSBMZD_BMQC
from
   (SELECT * from bfadminorganization where orgtype='33c21504-3384-42a7-8fc3-c1b5e9e982d0') dep
   inner join (SELECT * from bfadminorganization where orgtype='9edf25d1-b991-4dde-90b9-30145422d24d') org on dep.ownerid=org.id
/

