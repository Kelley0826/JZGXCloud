create view VW_FSZC_ROJKSQFT as
select CXVIEW."ROCXRQ",CXVIEW."ROCXLXMC",CXVIEW."ROCXLX",CXVIEW."ROCXBH",CXVIEW."ROCXSM",CXVIEW."ROCXJE",CXVIEW."ROYCXJE",CXVIEW."ROYGNM",CXVIEW."ROYGXM",CXVIEW."ROFTXX",CXVIEW."ROFTNM",CXVIEW."ROFYXMMC",CXVIEW."ROFTJE",CXVIEW."ROFTYCXJE",CXVIEW."ROFTZTCXJE",CXVIEW."ROZTCXJE",CXVIEW."IFCLOSE",CXVIEW."FTIFCLOSE",CXVIEW."RODJNM",ROSQLX_YSYQ as ysyq
 from (
 SELECT rosqdj.rosqdj_rq AS rocxrq,
    rosqdj.rosqdj_sqlxmc AS rocxlxmc,
    rosqdj.rosqdj_sqlx AS rocxlx,
    rosqdj.rosqdj_bh AS rocxbh,
    rosqdj.rosqdj_zy AS rocxsm,
    rosqdj.rosqdj_sqje AS rocxje,
    rosqdj.rosqdj_cxsqje AS roycxje,
    rosqdj.rosqdj_ygnm AS roygnm,
    rosqdj.rosqdj_ygxm AS roygxm,
    rosqft.rosqft_ftsm AS roftxx,
    rosqft.rosqft_nm AS roftnm,
    rosqft.rosqft_fyxmmc AS rofyxmmc,
    rosqft.rosqft_je AS roftje,
    rosqft.rosqft_ycxje AS roftycxje,
rosqft.rosqft_ztcxje AS roftztcxje,
    rosqdj.rosqdj_ztcxje AS roztcxje,
    rosqdj.rosqdj_ifclose AS ifclose,
    rosqft.rosqft_ifclose AS ftifclose,
        rosqdj.rosqdj_nm AS rodjnm
   FROM (rosqft
     LEFT JOIN rosqdj ON (((rosqft.rosqft_bxnm) = (rosqdj.rosqdj_nm))))
  WHERE not EXISTS
(SELECT rojkglsq_nm from rojkglsq WHERE rosqft.rosqft_nm=rojkglsq_ftid
and rojkglsq_ifcxwc= '1') AND((1 = 1) AND (rosqdj.rosqdj_zt = 6)
  AND (rosqft.rosqft_delflag = 0) AND (rosqdj.rosqdj_delflag = 0))
UNION ALL
 SELECT roywsq.roywsq_rq AS rocxrq,
    roywsq.roywsq_sqlxmc AS rocxlxmc,
    roywsq.roywsq_sqlx AS rocxlx,
    roywsq.roywsq_bh AS rocxbh,
    roywsq.roywsq_zy AS rocxsm,
    roywsq.roywsq_jkje AS rocxje,
    roywsq.roywsq_jkcxje AS roycxje,
    roywsq.roywsq_ygnm AS roygnm,
    roywsq.roywsq_ygxm AS roygxm,
    rojkft.rojkft_ftsm AS roftxx,
    rojkft.rojkft_nm AS roftnm,
    rojkft.rojkft_fyxmmc AS rofyxmmc,
    rojkft.rojkft_je AS roftje,
    rojkft.rojkft_yhk AS roftycxje,
0 AS roftztcxje,
    0 AS roztcxje,
    roywsq.roywsq_ifclose AS ifclose,
    0 AS ftifclose,
        roywsq.roywsq_nm AS rodjnm
   FROM (rojkft
     LEFT JOIN roywsq ON (((roywsq.roywsq_nm) = (rojkft.rojkft_bxnm))))
  WHERE ((1 = 1) AND (roywsq.roywsq_zt = 6) AND ((roywsq.roywsq_ifclose = 0) OR (roywsq.roywsq_ifclose IS NULL)) AND (roywsq.roywsq_sqje > (0)) AND ((roywsq.roywsq_ifzf = '0') OR (roywsq.roywsq_ifzf IS NULL)) AND ((roywsq.roywsq_ifcxwc = '0') OR (roywsq.roywsq_ifcxwc IS NULL)) AND ((roywsq.roywsq_jkifcxwc = '0') OR (roywsq.roywsq_jkifcxwc IS NULL))
  AND (roywsq.roywsq_delflag = 0) AND (rojkft.rojkft_delflag = 0))
UNION ALL
SELECT rosqdj.rosqdj_rq AS rocxrq,
    rosqdj.rosqdj_sqlxmc AS rocxlxmc,
    rosqdj.rosqdj_sqlx AS rocxlx,
    rosqdj.rosqdj_bh AS rocxbh,
    rosqdj.rosqdj_zy AS rocxsm,
    rosqdj.rosqdj_sqje AS rocxje,
    rosqdj.rosqdj_cxsqje AS roycxje,
    rosqdj.rosqdj_ygnm AS roygnm,
    rosqdj.rosqdj_ygxm AS roygxm,
    rosqft.rosqft_ftsm AS roftxx,
    rosqft.rosqft_nm AS roftnm,
    rosqft.rosqft_fyxmmc AS rofyxmmc,
    rosqft.rosqft_je AS roftje,
    rosqft.rosqft_ycxje AS roftycxje,
rosqft.rosqft_ztcxje AS roftztcxje,
    rosqdj.rosqdj_ztcxje AS roztcxje,
    rosqdj.rosqdj_ifclose AS ifclose,
    rosqft.rosqft_ifclose AS ftifclose,
        rosqdj.rosqdj_nm AS rodjnm
   FROM (rosqft
     LEFT JOIN fsroapplytravel rosqdj ON (((rosqft.rosqft_bxnm) = (rosqdj.rosqdj_nm))))
  WHERE not EXISTS
(SELECT rojkglsq_nm from rojkglsq WHERE rosqft.rosqft_nm=rojkglsq_ftid
and rojkglsq_ifcxwc= '1') AND((1 = 1) AND (rosqdj.rosqdj_zt = 6)
  AND (rosqft.rosqft_delflag = 0) AND (rosqdj.rosqdj_delflag = 0))
    ) CXVIEW left join ROSQLX on ROSQLX_NM=rocxlx
/

