create view VW_TAXADMINISTRATOR as
SELECT gspuser.id,
    gspuser.code,
    gspuser.name_chs AS name
   FROM gspuser gspuser
/

