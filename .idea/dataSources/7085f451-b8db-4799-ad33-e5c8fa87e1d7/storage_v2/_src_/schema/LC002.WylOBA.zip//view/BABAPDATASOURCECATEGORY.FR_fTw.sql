create view BABAPDATASOURCECATEGORY as
SELECT s1.id as Id,category_id  AS Pid,s1.user_id AS UserId,datasource_code AS Code,datasource_name_chs AS Name_CHS,datasource_name_cht AS Name_CHT,datasource_name_en AS Name_EN,datasource_name_es AS Name_ES,datasource_name_pt AS Name_PT,datasource_type AS Type,'datasource' AS ResType, create_time AS CreateTime,update_time  AS UpdateTime FROM BABAPDatasource s1 where backend_type = 2 union all SELECT s2.id as Id,category_pid  AS Pid,s2.user_id AS UserId, 
category_code  AS Code,category_name_chs AS Name_CHS,category_name_cht AS Name_CHT,category_name_en AS Name_EN,category_name_es AS Name_ES,category_name_pt AS Name_PT,category_type AS Type,'category' AS ResType, create_time AS CreateTime,update_time AS UpdateTime FROM BABAPCategory s2 where category_type ='datasource' and backend_type = 2
/

