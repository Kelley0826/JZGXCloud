create view VW_TAXTRAVELERSERVICETICKET as
SELECT travelerticket.id
	,travelerticket.taxorg
	,deu.taxperiod
	,travelerticket.invoicetype
	,travelerticket.invoicecode
	,travelerticket.invoicenum
	,travelerticket.invoicedate
	,travelerticket.amount
	,travelerticket.taxamount
	,travelerticket.amountandtax
	,travelerticket.passengername
	,travelerticket.passengeridcard
	,travelerticket.source
	,h.namefortax AS taxorgname
	,deu.SELECTCONFIRMSTATE
	,deu.CANDEDUCTION
	,travelerticket.updateinfo_createdon
FROM (
	SELECT taxinpassengerticket.id
		,taxinpassengerticket.taxorg
		,taxinpassengerticket.taxperiod
		,'31' AS invoicetype
		,taxinpassengerticket.invoicecode
		,taxinpassengerticket.invoicenum
		,taxinpassengerticket.departuretime AS invoicedate
		,taxinpassengerticket.notaxprice AS amount
		,taxinpassengerticket.tax AS taxamount
		,taxinpassengerticket.ticketprice AS amountandtax
		,taxinpassengerticket.passengername
		,taxinpassengerticket.passengeridcard
		,taxinpassengerticket.source
		,taxinpassengerticket.updateinfo_createdon
	FROM taxinpassengerticket
	UNION ALL
	SELECT taxinairticket.id
		,taxinairticket.taxorg
		,taxinairticket.taxperiod
		,'33' AS invoicetype
		,'' AS invoicecode
		,taxinairticket.eticketno AS invoicenum
		,taxinairticket.issueddate AS invoicedate
		,taxinairticket.notaxprice AS amount
		,taxinairticket.tax AS taxamount
		,(taxinairticket.fare + taxinairticket.fuelsurcharge) AS amountandtax
		,taxinairticket.passengername
		,taxinairticket.idcardno
		,taxinairticket.source
		,taxinairticket.updateinfo_createdon
	FROM taxinairticket
	UNION ALL
	SELECT taxintrainticket.id
		,taxintrainticket.taxorg
		,taxintrainticket.taxperiod
		,'32' AS invoicetype
		,'' AS invoicecode
		,taxintrainticket.ticketnumber AS invoicenum
		,taxintrainticket.departuretime AS invoicedate
		,taxintrainticket.notaxprice AS amount
		,taxintrainticket.tax AS taxamount
		,taxintrainticket.ticketprice AS amountandtax
		,taxintrainticket.passengername
		,taxintrainticket.passengeridcard
		,taxintrainticket.source
		,taxintrainticket.updateinfo_createdon
	FROM taxintrainticket
	) travelerticket
LEFT JOIN taxinvatinvoicededuction deu ON deu.parentid = travelerticket.id
LEFT JOIN bfmasterorganization h ON travelerticket.taxorg = h.id
/

