create view ERMPROJECTINFOVIEW as
SELECT ID ProjectGUID,Code ProjectCode,Name_chs ProjectName,parentinfo_layer Layer,parentinfo_isdetail IsDetail,'' TYPEPATH,parentinfo_parentelement ParentID,'0' STOPFLAG,(case when (select orgtype from bfadminorganization where id=bfProjectInfo.ownerorg)='33c21504-3384-42a7-8fc3-c1b5e9e982d0' then (select code from bfadminorganization where id=(select ownerid from bfadminorganization where id=bfProjectInfo.ownerorg)) else (select code from bfadminorganization where id=ownerorg) end) Companyid from bfProjectInfo
/

