create view VW_TAXINVATINVOICESELECTED as
SELECT t.id
	,t.invoicetypename_chs,
    t.invoicetypename_cht,
    t.invoicetypename_en,
    t.invoicetypename_es,
    t.invoicetypename_pt
	,t.invoicetypeid
	,t.invoicetypecode
	,t.taxorgid
	,t.invoicecode
	,t.invoicenumber
	,t.invoicedate
	,t.amount
	,t.taxamount
	,t.amountandtax
	,t.sellertaxpayername
	,t.sellertaxpayerid
	,t.selectconfirmstate
	,t.invveristate
	,t.candeduction
	,t.note
	,t.selecttype
	,t.selectedtime
	,t.selector
	,t.taxperiod
	,t.transfertax
	,t.taxorgname
	,t.namefortax
FROM (
	SELECT a.id
		,g.name_chs AS invoicetypename_chs,
            g.name_cht AS invoicetypename_cht,
            g.name_en AS invoicetypename_en,
            g.name_es AS invoicetypename_es,
            g.name_pt AS invoicetypename_pt
		,g.id AS invoicetypeid
		,g.code AS invoicetypecode
		,a.taxorgid
		,a.invoiceinfo_invoicecode AS invoicecode
		,a.invoiceinfo_invoicenumber AS invoicenumber
		,a.invoiceinfo_invoicedate AS invoicedate
		,a.invoiceinfo_amount AS amount
		,a.invoiceinfo_taxamount AS taxamount
		,a.invoiceinfo_amountandtax AS amountandtax
		,a.seller_taxpayername AS sellertaxpayername
		,a.seller_taxpayerid AS sellertaxpayerid
		,CASE 
			WHEN (b.selectconfirmstate IS NULL)
				THEN '0'
			ELSE b.selectconfirmstate
			END AS selectconfirmstate
		,a.invveristate
		,b.candeduction
		,a.note
		,b.selecttype
		,b.selectedtime
		,b.selector
		,b.taxperiod
		,b.transfertax
		,f.name_chs AS taxorgname
		,f.namefortax as namefortax
	FROM taxinvatinvoice a
	LEFT JOIN taxinvatinvoicededuction b ON a.id = b.parentid
	LEFT JOIN bfdftaxorg h ON a.taxorgid = h.id
	LEFT JOIN bfmasterorganization f ON h.bfmsorg = f.id
	LEFT JOIN bfinvoicetype g ON a.invoicetypeid = g.id
	
	UNION ALL
	
	SELECT a.id
		,g.name_chs AS invoicetypename_chs,
            g.name_cht AS invoicetypename_cht,
            g.name_en AS invoicetypename_en,
            g.name_es AS invoicetypename_es,
            g.name_pt AS invoicetypename_pt
		,g.id AS invoicetypeid
		,g.code AS invoicetypecode
		,a.taxorgid
		,a.vatinvoiceinfo_invoicecode AS invoicecode
		,a.vatinvoiceinfo_invoicenumber AS invoicenumber
		,a.vatinvoiceinfo_invoicedate AS invoicedate
		,a.vatinvoiceinfo_amount AS amount
		,a.vatinvoiceinfo_taxamount AS taxamount
		,a.vatinvoiceinfo_amountandtax AS amountandtax
		,a.seller_taxpayername AS sellertaxpayername
		,a.seller_taxpayerid AS sellertaxpayerid
		,CASE 
			WHEN (b.selectconfirmstate IS NULL)
				THEN '0'
			ELSE b.selectconfirmstate
			END AS selectconfirmstate
		,a.invveristate
		,b.candeduction
		,a.note
		,b.selecttype
		,b.selectedtime
		,b.selector
		,b.taxperiod
		,b.transfertax
		,f.name_chs AS taxorgname
		,f.namefortax as namefortax
	FROM taxinmotorsalesinvoice a
	LEFT JOIN taxinvatinvoicededuction b ON a.id = b.parentid
	LEFT JOIN bfinvoicetype g ON g.code = '03'
	LEFT JOIN bfdftaxorg h ON a.taxorgid = h.id
	LEFT JOIN bfmasterorganization f ON h.bfmsorg = f.id
	) t
WHERE invoicetypecode IN (
		'01'
		,'03'
		,'14'
		)
/

