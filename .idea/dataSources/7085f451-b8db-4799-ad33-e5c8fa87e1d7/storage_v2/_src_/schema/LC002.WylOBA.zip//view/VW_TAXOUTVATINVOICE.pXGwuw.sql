create view VW_TAXOUTVATINVOICE as
SELECT inv.id,
    inv.taxorg,
    inv.invoicetype,
    inv.billingtype,
    inv.specialtaxkindsign,
    inv.invoicestate,
    inv.invoicecode,
    inv.invoicenumber,
    inv.invoicedate,
    inv.buyertaxpayername,
    inv.buyertaxpayeridno,
    inv.amount,
    inv.taxamount,
    inv.amountplustax,
    inv.note,
    inv.sourcetype,
    inv.invalidsign,
    inv.printsign,
    inv.listsign,
    inv.updateinfo_createdby,
    inv.updateinfo_createdon,
    inv.updateinfo_lastchangedby,
    inv.updateinfo_lastchangedon,
    t.name_chs AS taxorgname,
    t.name_chs AS taxorgname_chs,
    t.name_cht AS taxorgname_cht,
    t.name_en AS taxorgname_en,
    t.name_es AS taxorgname_es,
    t.name_pt AS taxorgname_pt
   FROM ((taxoutvatinvoice inv
     LEFT JOIN bfdftaxorg h ON (((inv.taxorg) = (h.id))))
     LEFT JOIN bfmasterorganization t ON (((h.bfmsorg) = (t.id))))
/

