create view VW_BFKMZD2020 as
select b.ledger as hsgxLedger, a.chartOfAcc,   
a.ID, a.Code,
a.Name_chs as kmName_chs, a.Name_en as kmName_en, a.Name_cht as kmName_cht,
a.Name_es as kmName_es, a.Name_pt as kmName_pt,
a.FullName_chs,  a.FullName_en, a.FullName_cht,  a.FullName_es, a.FullName_pt, 
a.MnemonicCode, 
a.TypeFlag, a.Ledger, a.IsDisabled, a.AccountType,          
a.BalanceDir, a.CashAccTitle, a.IsJournalEntry, a.IsBankBook, a.IsOutStatement,
a.treeInfo_path, a.treeInfo_layer, b.treeInfo_isDetail,
a.AccTitleProp, c.Code as sxbh, 
c.Name_chs as sxName_chs, c.Name_en as sxName_en, c.Name_cht as sxName_cht, c.Name_es as sxName_es, c.Name_pt as sxName_pt,
null as version 
from bfAccountTitle2020 a
inner join bfAccTitleAccRlat2020 b on (a.id = b.accountTitleId)
inner join bfacctitleprop2020 c on (a.acctitleProp = c.id)
/

