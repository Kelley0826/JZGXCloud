create view VW_TBHZGX_YSZZ as
select tbhzgx_lbnm, tbhzgx_fjnm as tbyszz_fjnm , tbhzgx_jc as tbyszz_jc, tbyszz_zznm,tbyszz_zzbh ,tbyszz_zzmc ,tbyszz_ifvalid,tbyszz_xz
from tbhzgx join tbyszz on tbhzgx_xmbh = tbyszz_zznm
/

