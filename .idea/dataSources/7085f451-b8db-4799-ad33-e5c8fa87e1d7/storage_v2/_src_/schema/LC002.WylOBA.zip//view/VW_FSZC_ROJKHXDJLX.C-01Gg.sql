create view VW_FSZC_ROJKHXDJLX as
SELECT robxlx.robxlx_nm AS nm,
    robxlx.robxlx_bh AS bh,
    robxlx.robxlx_mc AS mc,
    'FSROBX' AS ywly
   FROM robxlx
UNION ALL
 SELECT rohklx.rohklx_nm AS nm,
    rohklx.rohklx_bh AS bh,
    rohklx.rohklx_mc AS mc,
    'FSROHK' AS ywly
   FROM rohklx
/

