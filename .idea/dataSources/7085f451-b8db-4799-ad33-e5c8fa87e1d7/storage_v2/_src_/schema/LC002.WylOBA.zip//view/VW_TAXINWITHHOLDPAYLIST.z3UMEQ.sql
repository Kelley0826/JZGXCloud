create view VW_TAXINWITHHOLDPAYLIST as
SELECT ticket.id
	,ticket.taxorg
	,ticket.fillingdate
	,ticket.governmentname
	,ticket.withholdpayproject
	,ticket.withholdpaydocnum
	,ticket.tax
	,ticket.source
	,deu.taxperiod
	,h.namefortax AS taxorgname
	,deu.selectconfirmstate
	,deu.candeduction
	,ticket.updateinfo_createdon
FROM taxinwithholdpaylist ticket
LEFT JOIN taxinvatinvoicededuction deu ON deu.parentid = ticket.id
LEFT JOIN bfmasterorganization h ON ticket.taxorg = h.id
/

