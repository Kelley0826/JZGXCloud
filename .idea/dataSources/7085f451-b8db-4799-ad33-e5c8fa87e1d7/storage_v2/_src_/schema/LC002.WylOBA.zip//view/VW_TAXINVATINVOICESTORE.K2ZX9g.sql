create view VW_TAXINVATINVOICESTORE as
SELECT t.id
	,t.invoicetypename_chs
	,t.invoicetypename_cht
	,t.invoicetypename_en
	,t.invoicetypename_es
	,t.invoicetypename_pt
	,t.invoicetypeid
	,t.invoicetypecode
	,t.taxorgid
	,t.invoicecode
	,t.invoicenumber
	,t.invoicedate
	,t.amount
	,t.taxamount
	,t.amountandtax
	,t.sellertaxpayername
	,t.sellertaxpayerid
	,t.sourcetype
	,t.invveristate
	,t.doccode
	,t.note
	,t.taxorgname
	,t.checkcode
	,t.buyer_taxpayerid
	,t.namefortax
	,t.SELECTCONFIRMSTATE
	,t.updateinfo_createdon
FROM (
	SELECT a.id
		,g.name_chs AS invoicetypename_chs
		,g.name_cht AS invoicetypename_cht
		,g.name_en AS invoicetypename_en
		,g.name_es AS invoicetypename_es
		,g.name_pt AS invoicetypename_pt
		,g.id AS invoicetypeid
		,g.code AS invoicetypecode
		,a.taxorgid
		,a.invoiceinfo_invoicecode AS invoicecode
		,a.invoiceinfo_invoicenumber AS invoicenumber
		,a.invoiceinfo_invoicedate AS invoicedate
		,a.invoiceinfo_amount AS amount
		,a.invoiceinfo_taxamount AS taxamount
		,a.invoiceinfo_amountandtax AS amountandtax
		,a.seller_taxpayername AS sellertaxpayername
		,a.seller_taxpayerid AS sellertaxpayerid
		,a.sourcetype
		,a.invveristate
		,e.doccode
		,a.note
		,b.name_chs AS taxorgname
		,a.checkcode
		,a.buyer_taxpayerid
		,b.namefortax
		,c.SELECTCONFIRMSTATE
		,a.updateinfo_createdon
	FROM taxinvatinvoice a
	LEFT JOIN taxininvoicerelation e ON a.id = e.parentid
	LEFT JOIN bfinvoicetype g ON a.invoicetypeid = g.id
	LEFT JOIN bfmasterorganization b ON a.taxorgid = b.id
	LEFT JOIN TAXINVATINVOICEDEDUCTION c on c.parentid = a.id
	
	UNION ALL
	
	SELECT a.id
		,g.name_chs AS invoicetypename_chs
		,g.name_cht AS invoicetypename_cht
		,g.name_en AS invoicetypename_en
		,g.name_es AS invoicetypename_es
		,g.name_pt AS invoicetypename_pt
		,g.id AS invoicetypeid
		,g.code AS invoicetypecode
		,a.taxorgid
		,a.vatinvoiceinfo_invoicecode AS invoicecode
		,a.vatinvoiceinfo_invoicenumber AS invoicenumber
		,a.vatinvoiceinfo_invoicedate AS invoicedate
		,a.vatinvoiceinfo_amount AS amount
		,a.vatinvoiceinfo_taxamount AS taxamount
		,a.vatinvoiceinfo_amountandtax AS amountandtax
		,a.seller_taxpayername AS sellertaxpayername
		,a.seller_taxpayerid AS sellertaxpayerid
		,a.sourcetype
		,a.invveristate
		,e.doccode
		,a.note
		,b.name_chs AS taxorgname
		,a.checkcode
		,a.buyer_taxpayerid
		,b.namefortax
		,c.SELECTCONFIRMSTATE
		,a.updateinfo_createdon
	FROM taxinmotorsalesinvoice a
	LEFT JOIN taxininvoicerelation e ON a.id = e.parentid
	LEFT JOIN bfinvoicetype g ON g.id = '26fdb22d-af2b-4aaf-a8e5-1a6c4a20e4bf'
	LEFT JOIN bfmasterorganization b ON a.taxorgid = b.id
	LEFT JOIN TAXINVATINVOICEDEDUCTION c on c.parentid = a.id
	) t
/

