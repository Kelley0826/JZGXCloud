create view VW_TAXINCUSTOMSDEDUCTIONLIST as
SELECT cus.id
	,cus.taxorg as taxorgid
	,cus.tax
	,cus.paymentnum
	,cus.importportcode
	,cus.importportname
	,cus.fillingdate
	,cus.source
	,deu.taxperiod
	,deu.selectconfirmstate
	,deu.candeduction
	,h.namefortax AS taxorgname
	,cus.updateinfo_createdon
FROM taxincustomsdeductionlist cus
LEFT JOIN taxinvatinvoicededuction deu ON deu.parentid = cus.id
LEFT JOIN bfmasterorganization h ON cus.taxorg = h.id
/

